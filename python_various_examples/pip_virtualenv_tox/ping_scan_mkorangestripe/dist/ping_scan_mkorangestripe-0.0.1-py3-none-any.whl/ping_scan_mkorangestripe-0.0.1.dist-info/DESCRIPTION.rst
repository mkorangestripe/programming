# ping_scan.py

### ping_scan.py
###### Scan a network by pinging a CIDR range in parallel.
![Output from ping_scan.py](sample-output/ping_scan.png)


